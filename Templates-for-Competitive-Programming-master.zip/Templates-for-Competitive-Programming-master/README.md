# Template-Code-for-Competitive-Programming

The well-designed ones are copied from [Zimpha's Repo](https://github.com/zimpha/algorithmic-library) and the rest are written by myself.

